﻿using System;
namespace Zadanie1
{
    class LiczbyDoWyswietlenia
    {
        public int calkowita;
        public double zmiennoprzecinkowa;
        public string text;

        public LiczbyDoWyswietlenia(int calkowita, double zmiennoprzecinkowa)
        {            
            this.calkowita = calkowita;
            this.zmiennoprzecinkowa = zmiennoprzecinkowa;
        }
        public LiczbyDoWyswietlenia(): this(1, 1.1)
        {
        }
        public LiczbyDoWyswietlenia(int calkowita, double zmiennoprzecinkowa, string text)
        {
            this.calkowita = calkowita;
            this.zmiennoprzecinkowa = zmiennoprzecinkowa;
            this.text = text;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("\n Konstruktor 1");
            LiczbyDoWyswietlenia liczbyDoWyswietlenia_1 = new LiczbyDoWyswietlenia(2, 2.2);
            Console.WriteLine(" liczbyDoWyswietlenia_1._calkowita = " + liczbyDoWyswietlenia_1.calkowita);
            Console.WriteLine(" liczbyDoWyswietlenia_1._zmiennoprzecinkowa = " + liczbyDoWyswietlenia_1.zmiennoprzecinkowa);
            
            Console.WriteLine("\n Konstruktor 2");
            LiczbyDoWyswietlenia liczbyDoWyswietlenia_2 = new LiczbyDoWyswietlenia();
            Console.WriteLine(" liczbyDoWyswietlenia_2._calkowita = " + liczbyDoWyswietlenia_2.calkowita);
            Console.WriteLine(" liczbyDoWyswietlenia_2._zmiennoprzecinkowa = " + liczbyDoWyswietlenia_2.zmiennoprzecinkowa);
           
            Console.WriteLine("\n Konstruktor 3");
            LiczbyDoWyswietlenia liczbyDoWyswietlenia_3 = new LiczbyDoWyswietlenia(3, 3.3, "Trzeci parametr typu STRING !");
            Console.WriteLine(" liczbyDoWyswietlenia_3._calkowita = " + liczbyDoWyswietlenia_3.calkowita);
            Console.WriteLine(" liczbyDoWyswietlenia_3._zmiennoprzecinkowa = " + liczbyDoWyswietlenia_3.zmiennoprzecinkowa);
            Console.WriteLine(" liczbyDoWyswietlenia_3.text = " + liczbyDoWyswietlenia_3.text);

            Console.ReadLine();
        }
    }
}
