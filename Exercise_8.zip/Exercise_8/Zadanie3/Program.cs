﻿using System;
namespace Zadanie3
{
    public class Punkt
    {
        public int x;
        public int y;
        public Punkt(int x, int y)
        {
            this.x = x;
            this.y = y;
        }
        public Punkt() : this(1, 1)
        {
        }
    }
    public class Punkt_3D : Punkt
    {
        public int z { get; private set; }
        public string text1, text2, text3, text4;
     
        public Punkt_3D(int x, int y, int z) : base(x, y)
        {
            if (z < 100)
            {
                Console.Write(" Podaj X: ");
                x = int.Parse(Console.ReadLine());
                Console.Write(" Podaj Y: ");
                y = int.Parse(Console.ReadLine());
                Console.Write(" Podaj Z: ");
                z = int.Parse(Console.ReadLine());
            }
            this.x = x;
            this.y = y;
            this.z = z;
        }
        public Punkt_3D(string text1, string text2, string text3, string text4)
        {
            this.text1 = text1;
            this.text2 = text2;
            this.text3 = text3;
            this.text4 = text4;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("\n Konstruktor 1.1 (z < 100):");
            Punkt_3D punkt1_3D = new Punkt_3D(1, 2, 3);            
            Console.WriteLine(" punkt1_3D.x = " + punkt1_3D.x);
            Console.WriteLine(" punkt1_3D.y = " + punkt1_3D.y);
            Console.WriteLine(" punkt1_3D.z = " + punkt1_3D.z);

            Console.WriteLine("\n Konstruktor 1.2 (z >= 100):");
            Punkt_3D punkt2_3D = new Punkt_3D(100, 200, 300);            
            Console.WriteLine(" punkt2_3D.x = " + punkt2_3D.x);
            Console.WriteLine(" punkt2_3D.y = " + punkt2_3D.y);
            Console.WriteLine(" punkt2_3D.z = " + punkt2_3D.z);

            Console.WriteLine("\n Konstruktor 2 (tekstowy typ danych)");
            Punkt_3D text_3D = new Punkt_3D("Text1", "Text2", "Text3", "Text4");            
            Console.WriteLine(" text_3D.text1 = " + text_3D.text1);
            Console.WriteLine(" text_3D.text2 = " + text_3D.text2);
            Console.WriteLine(" text_3D.text3 = " + text_3D.text3);
            Console.WriteLine(" text_3D.text4 = " + text_3D.text4);
        }
    }
}
