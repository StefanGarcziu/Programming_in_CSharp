﻿using System;

namespace Zadanie2
{
    class Program
    {
        public class TestClass
        {
            public int TestProperty { get; set; } = 2;
            public TestClass()
            {
                if (TestProperty == 1)
                {
                    Console.WriteLine("Shall this be executed?");
                }

                if (TestProperty == 2)
                {
                    Console.WriteLine(" \n Or shall this be executed");
                }
            }
        }
        static void Main(string[] args)
        {
            var testInstance = new TestClass() { TestProperty = 1 };
            Console.WriteLine(testInstance.TestProperty);
        }
    }
}
