﻿using System;

namespace Nowy_projekt
{
    class Program
    {
        static void Main(string[] args)
        {
            string[,] para = new string[3, 2];
            para[0, 0] = "Ewelina";
            para[0, 1] = "Darek";
            para[1, 0] = "Ania";
            para[1, 1] = "Dawid";
            para[2, 0] = "Krzysiek";
            para[2, 1] = "Ela";

            for (int i = 0; i <= 3; i++)
            {
                Console.Write("Para: ");
                for (int j = 0; j < 2; j++)
                {
                    Console.Write(para[i, j] + " ");
                }
                Console.WriteLine();
            }
            Console.ReadLine();
        }
    }
}
