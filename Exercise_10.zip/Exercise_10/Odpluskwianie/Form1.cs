﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Odpluskwianie
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private int kwadrat(int argument)
        {
            int wartosc;
            wartosc = argument * argument;
            if (wartosc < 0) throw new Exception("Funkcja nie powinna zwracać wartości ujemnej!");
            return wartosc;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int x = 1234;
                int y = kwadrat(x);
                y = kwadrat(y);
                string sy = y.ToString();
                MessageBox.Show(sy);
            }
            catch(Exception ex)
            {
                MessageBox.Show("Błąd:" + ex.Message, "Przechwycony wyjątek w metodzie button1_Click",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
