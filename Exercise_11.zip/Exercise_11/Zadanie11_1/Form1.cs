﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zadanie11_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int y = 0;
            int refNum;
            string result = "";
            int[] index = new int[4];
            string[] wyspy = new String[4];

            index[0] = 1;
            index[1] = 3;
            index[2] = 0;
            index[3] = 2;
            
            wyspy[0] = "Bermudy";
            wyspy[1] = "Fuji";
            wyspy[2] = "Azory";
            wyspy[3] = "Kreta";
            
            while (y < 4)
            {
                refNum = index[y];
                result += "\n wyspa = ";
                result += wyspy[refNum];  
                y = y + 1;
            }

            MessageBox.Show(result);
        }
    }
}
