﻿using System;

namespace Zad11_2
{
    class Program
    {
        class trojkat
        {
            double powierzchnia;
            int wysokosc;
            int dlugosc;
            void ustawPowierzchnie()
            {
                powierzchnia = (wysokosc * dlugosc) / 2;
            }

        }
                    public static void Main(String[] args)
            {

                string wyniki = "";
                int x = 0;
                trojkat[] ta = new trojkat(4);
                while (x < 4)
                {
                    ta[x] = new trojkat();
                    ta[x].wysokosc = (x + 1) * 2;
                    ta[x].dlugosc = x + 4;
                    ta[x].ustawPowierzchnie();
                    wyniki += "trójkąt " + x + ", powierzchnia";
                    wyniki += " = " + ta[x].powierzchnia + "\n";
                    x = x + 1;
                }
                int y = x;
                x = 27;
                trojkat t5 = ta[2];
                ta[2].powierzchnia = 343;
                wyniki += "y = " + y;
                MessageBox.Show(wyniki + ", t5 powierzchnia = " + t5.powierzchnia);
            }

    }
}
