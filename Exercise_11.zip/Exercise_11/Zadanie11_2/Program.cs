﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zadanie11_2
{
    static class Program
    {

        class trojkat
        {
            double powierzchnia;
            int wysokosc;
            int dlugosc;
            public static void Main(String[] args)
            {

                string wyniki = "";
                int x = 0;
                trojkat[] ta = new trojkat(4);
                while (x < 4)
                {
                    ta[x] = new trojkat();
                    ta[x].wysokosc = (x + 1) * 2;
                    ta[x].dlugosc = x + 4;
                    ta[x].ustawPowierzchnie();
                    wyniki += "trójkąt " + x + ", powierzchnia";
                    wyniki += " = " + ta[x].powierzchnia + "\n";
                    x = x + 1;
                }
                int y = x;
                x = 27;
                trojkat t5 = ta[2];
                ta[2].powierzchnia = 343;
                wyniki += "y = " + y;
                MessageBox.Show(wyniki + ", t5 powierzchnia = " + t5.powierzchnia);
            }
            void ustawPowierzchnie()
            {
                powierzchnia = (wysokosc * dlugosc) / 2;
            }

        }

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
