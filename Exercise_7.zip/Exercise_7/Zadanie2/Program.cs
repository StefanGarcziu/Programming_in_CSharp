﻿using System;
namespace Zadanie2
{
    class Pierwiastki
    {        
        public double a;
        public double b;
        public double c;
        public double delta;
        public double x1;
        public double x2;
        public double x;
    }
    class Program
    {        
        static Pierwiastki OdczytanieWielkosci()
        {
            Pierwiastki liczby = new Pierwiastki();
            Console.WriteLine("Podaj liczbę A: ");
            liczby.a = double.Parse(Console.ReadLine());
            Console.WriteLine("Podaj liczbę B: ");
            liczby.b = double.Parse(Console.ReadLine());
            Console.WriteLine("Podaj liczbę C: ");
            liczby.c = double.Parse(Console.ReadLine());
            Console.WriteLine();
            return liczby;
        }
        static void ObliczeniePierwiastkow(Pierwiastki liczby)
        {
            liczby.delta = liczby.b * liczby.b - 4.0 * liczby.a * liczby.c;
            if (liczby.a == 0.0)
            {
                liczby.x = -(liczby.c) / liczby.b;
                Console.WriteLine("X = {0}", liczby.x);
            }
            else if (liczby.b == 0.0 && -(liczby.c) / liczby.a > 0.0)
            {
                liczby.x1 = Math.Sqrt(-(liczby.c) / liczby.a);
                liczby.x2 = -Math.Sqrt(-(liczby.c) / liczby.a);

                Console.WriteLine("X1 = {0}, X2 = {1}", liczby.x1, liczby.x2);
            }
            else if (liczby.delta == 0.0)
            {
                liczby.x = -(liczby.b) / (2.0 * liczby.a);
                Console.WriteLine("X = {0}", liczby.x);
            }
            else if (liczby.delta > 0.0)
            {
                liczby.x1 = (-(liczby.b) - Math.Sqrt(liczby.delta)) / (2.0 * liczby.a);
                liczby.x2 = (-(liczby.b) + Math.Sqrt(liczby.delta)) / (2.0 * liczby.a);

                Console.WriteLine("X1 = {0}, X2 = {1}", liczby.x1, liczby.x2);
            }
            else
            {
                Console.WriteLine("D < 0, nie ma pierwiastków");
            }
        }
        static void Main(string[] args)
        {            
            var printABC = OdczytanieWielkosci();
            ObliczeniePierwiastkow(printABC);

            Console.ReadLine();
        }
    }
}

