﻿using System;
namespace Zadanie1
{
    class LiczbyDoWyswietlenia
    {
        public int calkowita;
        public double zmiennoprzecinkowa;
    }
    class Program
    {
        static LiczbyDoWyswietlenia OdczytLiczbCalkowitych()
        {
            LiczbyDoWyswietlenia c = new LiczbyDoWyswietlenia();
            Console.WriteLine("Podaj liczbę całkowitą: ");
            c.calkowita = int.Parse(Console.ReadLine()); 
            return c;
        }
        static void WyswietlenieLiczbCalkowitych(LiczbyDoWyswietlenia c)
        {
            Console.WriteLine();
            Console.WriteLine($"Liczba calkowita: {c.calkowita}");
        }
        static LiczbyDoWyswietlenia OdczytLiczbZmiennoprzecinkowych()
        {
            LiczbyDoWyswietlenia z = new LiczbyDoWyswietlenia();
            Console.WriteLine("Podaj liczbę zmiennoprzecinkową: ");
            z.zmiennoprzecinkowa = double.Parse(Console.ReadLine());
            return z;
        }
        static void WyswietlenieLiczbZmiennoprzecinkowych(LiczbyDoWyswietlenia z)
        {
            Console.WriteLine();
            Console.WriteLine($"Liczba zmiennoprzecinkowa: {z.zmiennoprzecinkowa}");
        }
        static void Main(string[] args)
        {
            var firstNumber = OdczytLiczbCalkowitych();
            var secondNumber = OdczytLiczbZmiennoprzecinkowych();
            WyswietlenieLiczbCalkowitych(firstNumber);
            WyswietlenieLiczbZmiennoprzecinkowych(secondNumber);

            Console.ReadLine();
        }
    }
}
