﻿using System;
namespace Zadanie3
{
    class Matrix
    {
        public double up;
        public double down;
        public double[,] matrix; 
    }
    class Program
    {
        static Matrix ReadMatrix(int r, int c)
        {
            Matrix read = new Matrix();
            read.matrix = new double[r, c];
            for (int i = 0; i < r; i++)
                for (int j = 0; j < c; j++)
                    read.matrix[i, j] = double.Parse(Console.ReadLine());
            return read;
        }
        static double UpperDiagonal(Matrix read)
        {            
            if (read.matrix.GetLength(0) < read.matrix.GetLength(1))
            {
                for (int i = 0; i < read.matrix.GetLength(0); i++)
                {
                    int j = i + 1;
                    read.up += read.matrix[i, j];
                }
            }
            else if (read.matrix.GetLength(0) > read.matrix.GetLength(1))
            {
                int i = 0;
                for (int j = 1; j < read.matrix.GetLength(1); j++)
                {
                    read.up += read.matrix[i, j];
                    i = j;
                }
            }
            else
            {
                for (int i = 0; i < read.matrix.GetLength(0) - 1; i++)
                {
                    int j = i + 1;
                    read.up += read.matrix[i, j];
                }
            }
            return read.up;
        }

        static double LowerDiagonal(Matrix read)
        {            

            if (read.matrix.GetLength(0) > read.matrix.GetLength(1))
            {
                for (int j = 0; j < read.matrix.GetLength(1); j++)
                {
                    int i = j + 1;
                    read.down += read.matrix[i, j];
                }
            }
            else if (read.matrix.GetLength(0) < read.matrix.GetLength(1))
            {
                int j = 0;
                for (int i = 1; i < read.matrix.GetLength(0); i++)
                {
                    read.down += read.matrix[i, j];
                    j = i;
                }
            }
            else
            {
                for (int j = 0; j < read.matrix.GetLength(1) - 1; j++)
                {
                    int i = j + 1;
                    read.down += read.matrix[i, j];
                }
            }
            return read.down;
        }

        static void Main(string[] args)
        {
            Console.Write("Podaj ilość wierszy: ");
            int w = int.Parse(Console.ReadLine());
            Console.Write("Podaj ilość kolumn: ");
            int k = int.Parse(Console.ReadLine());
            Console.Write("Wprowadź pierwszy element, a następnie następujące: ");

            var matrix = ReadMatrix(w, k);

            double up = UpperDiagonal(matrix);
            double down = LowerDiagonal(matrix);
            Console.Write("Suma górnej przekątnej = {0} ", up);
            Console.WriteLine();
            Console.Write("Suma dolnej przekątnej = {0} ", down);

            Console.ReadLine();
        }
    }
}
