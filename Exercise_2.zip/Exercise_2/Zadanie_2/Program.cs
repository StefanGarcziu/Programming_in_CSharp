﻿using System;

namespace Zadanie_2
{
    class Program
    {
        static double Bank_deposit(double oprocentowanie, double okres_oszczedzania, double kwota_lokaty)
        {            
            int a = 100; //   100 %
            int b = 12;  // 12 miesięcy w roku
            int c = 1;   // 1 = 100%
            float d = 0.81f; // 100% - 19% = 81%   Wielkość odsetek pomniejszona o podatek Belki (19%) 

            double lokata_bankowa = ((okres_oszczedzania / b * oprocentowanie) / a + c) * kwota_lokaty;
            double odsetek = lokata_bankowa - kwota_lokaty;
            double zmniejszony_odsetek = odsetek * d;

            return zmniejszony_odsetek;
        }
        public static void Main(string[] args)
        {      
            Console.Write("Oprocentowanie (za 12 miesięcy): ");
            double oprocentowanie = Convert.ToDouble(Console.ReadLine());

            Console.Write("Okres oszczędzania (wskazać liczbę miesięcy): ");
            double okres_oszczedzania = Convert.ToDouble(Console.ReadLine());

            Console.Write("Kwota lokaty: ");
            double kwota_lokaty = Convert.ToDouble(Console.ReadLine());

            double wielkosc = Bank_deposit(oprocentowanie, okres_oszczedzania, kwota_lokaty);

            Console.WriteLine("Wielkość odsetek pomniejszona o podatek Belki (19%)  = {0:f2} ", wielkosc);          

            Console.ReadLine();
        }
    }
}
