﻿using System;

namespace Zadanie_1
{
    class Program
    {
        static void PrintLine(int n)
        {
            int i = 0;
            while(i < n)
            {
                Console.Write("*");
                i++;
            }
            Console.WriteLine();
        }
        static void PrintSquare(int n)
        {
            int i = 0;
            while(i < n)
            {
                PrintLine(n);
                i++;
            }
        }
        static void PrintTriangle(int n)
        {
            int i = 1;
            while (i <= n)
            {
                PrintLine(i);
                i++;
            }
        }
        public static void Main(string[] args)
        {                        
            Console.WriteLine("Wpisz 1 lub 2 (1 - kwadrat, 2 - trójkąt)");
            string f = Console.ReadLine();
            Console.WriteLine("Podaj rozmiar n: ");
            int n = int.Parse(Console.ReadLine());

            if (f == "1")
            {
                PrintSquare(n); 
            }

            else 
            {                
                PrintTriangle(n);
            }

            Console.ReadLine();
        }
    }
}
