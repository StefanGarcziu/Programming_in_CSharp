﻿using System;

namespace Zadanie_3
{
    class Program
    {        
        static int OszacowanieKosztow(int dekor, int napoj, int ilosc)
        {            
            int suma = 300; // przyjęcie do realizacji...

            if (dekor == 1) //  Rodzaj dekoracji:
            {
                suma += 250; // wersja oszczędna 250 zł
            }
            else 
            {
                suma += 400; // wersja pełna 400 zł 
            }

            if (napoj == 1) // Rodzaj napojów:
            {
                ilosc *= 45; // bezalkoholowe(45 zł) * Ilość osób
                suma += ilosc;
            }
            else
            {
                ilosc *= 90; // z alkoholem(90 zł) * Ilość osób
                suma += ilosc;
            }
                return suma;
        }
        static void Main(string[] args)
        {
            
        Console.Write("Oszacować koszt organizacji przyjęcia? (1-tak / 2-nie) ");
        int sprawdzenie_1 = int.Parse(Console.ReadLine());

        while (sprawdzenie_1 == 1)
        {
        Console.Write("Rodzaj dekoracji? (1-oszczędna / 2-pełna) ");
        int dekor = int.Parse(Console.ReadLine());

        Console.Write("Rodzaj napojów? (1-bezalkoholowe / 2-z alkoholem) ");
        int napoj = int.Parse(Console.ReadLine());

        Console.WriteLine("Ilość osób? ");
        int ilosc = int.Parse(Console.ReadLine());

        int suma = OszacowanieKosztow(dekor, napoj, ilosc); // wykorzystanie metody() 
        Console.WriteLine("Suma = {0:f2} zł ", suma);

        Console.Write("Ponownie oszacować koszt organizacji przyjęcia? (1-tak / 2-nie) ");

        int sprawdzenie_2 = int.Parse(Console.ReadLine());
        sprawdzenie_1 = sprawdzenie_2;                   
            }            
        Console.ReadKey();
        }
    }
}
