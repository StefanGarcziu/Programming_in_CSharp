﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zadanie2
{
    public partial class Form1 : Form
    {
        Facet pawel;
        Facet robert;
        int bank = 100;


        public Form1()
        {
            InitializeComponent();
            robert = new Facet();
            robert.Nazwa = "Robert";
            robert.Pieniadze = 100;

            pawel = new Facet();
            pawel.Nazwa = "Pawel";
            pawel.Pieniadze = 50;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (bank >= 10)
            {
                bank -= robert.OtrzymaPieniadze(10);
                UpdateForm();
            }
            else
                MessageBox.Show("W banku brak pieniadze");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            bank += pawel.DajPienadze(5);
            UpdateForm();
        }

        public void UpdateForm()
        {
            KasaRobert.Text = robert.Nazwa + "ma" + robert.Pieniadze + "zl";
            KasaPawel.Text = pawel.Nazwa + "ma" + pawel.Pieniadze + "zl";
            KasaBanku.Text = "W banku jest" + bank + "zl";
        }

    }
}
