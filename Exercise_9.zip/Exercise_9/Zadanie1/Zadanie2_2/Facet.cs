﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zadanie2_2
{
    class Facet
    {
        public string Nazwa;
        public int Pieniadze;
        public int DajPieniadze(int ilosc)
        {
            if (ilosc <= Pieniadze && ilosc > 0)
            {
                Pieniadze -= ilosc;
                return ilosc;
            }
            else
            {
                MessageBox.Show("Nie mam wystarczającej ilości pieniędzy = " + ilosc + " zł", Nazwa);
                return 0;
            }
        }

        public int OtrzymajPieniadze(int ilosc)
        {
            if (ilosc > 0)
            {
                Pieniadze += ilosc;
                return ilosc;
            }
            else
            {
                MessageBox.Show(ilosc + "nie pobiore kwoty od", Nazwa);
                return 0;
            }
        }
    }
}
