﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zadanie2_2
{
    public partial class Form1 : Form
    {
        Facet Pawel;
        Facet Robert;
        int bank = 1000;
        public Form1()
        {
            InitializeComponent();

            Robert = new Facet();
            Robert.Nazwa = "Robert";
            Robert.Pieniadze = 50;

            Pawel = new Facet();
            Pawel.Nazwa = "Paweł";
            Pawel.Pieniadze = 100;

            this.button1.Text = "Daj 10 zł Robertowi";
            this.button2.Text = "Otrzymaj 5 zł od Pawła";
            this.robertDajePawlowi.Text = "Robert daje Pawłowi 10 zł";
            this.pawelDajeRobertowi.Text = "Paweł daje 5 zł Robertowi";

            UpdateForm();
        }
        private void button1_Click(object sender, EventArgs e)
        {          
            if (bank >= 10)
            {
                bank -= Robert.OtrzymajPieniadze(10);
                UpdateForm();
            }
            else
                MessageBox.Show("W banku brak pieniądzy");
        }
        private void button2_Click(object sender, EventArgs e)
        {
            bank += Pawel.DajPieniadze(5);
            UpdateForm();
        }
        public void UpdateForm()
        {
            label1.Text = Robert.Nazwa + " ma: " + Robert.Pieniadze + "zł";
            label2.Text = Pawel.Nazwa + " ma: " + Pawel.Pieniadze + "zł";
            label3.Text = "W banku jest " + bank + " zł";
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void label2_Click(object sender, EventArgs e)
        {

        }
        private void label3_Click(object sender, EventArgs e)
        {

        }
        private void robertDajePawlowi_Click(object sender, EventArgs e)
        {
            Pawel.OtrzymajPieniadze(Robert.DajPieniadze(10));
            UpdateForm();
        }
        private void pawelDajeRobertowi_Click(object sender, EventArgs e)
        {
            Robert.OtrzymajPieniadze(Pawel.DajPieniadze(5));
            UpdateForm();
        }
    }
}
