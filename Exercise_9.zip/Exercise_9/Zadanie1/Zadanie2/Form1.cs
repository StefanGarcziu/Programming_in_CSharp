﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zadanie2
{
    public partial class Form1 : Form
    {
        Robert = new Facet();
        Robert.Nazwa = "Robert";
        Robert.Pieniadze = 100;

        Pawel = new Facet();
        Pawel.Nazwa = "Paweł";
        Pawel.Pieniadze = 50;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (bank >= 10)
            {
                bank -= robert.OtrzymajPieniadze(10);
                UpdateForm();
            }
            else
                MessageBox.Show("W banku brak pieniądzy");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            bank += pawel.DajPieniadze(5);
            UpdateForm();
        }

        public void UpdateForm()
        {
            KasaRobert.Text = robert.Nazwa + "ma" + robert.Pieniadze + "zł";
            KasaPawel.Text = pawel.Nazwa + "ma" + pawel.Pieniadze + "zł";
            KasaBanku.Text = "W banku jest" + bank + "zł";
        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }
    }
}
