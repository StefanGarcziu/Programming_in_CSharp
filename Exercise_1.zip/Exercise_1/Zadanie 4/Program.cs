﻿using System;

namespace Zadanie_4
{
    class Program
    {
        static void Main(string[] args)        
        {
            double d = 2.54;
            string f;
            Console.WriteLine("Wpisz 1 lub 2 (1 - cale na cm, 2 - cm na cale)");
            f = Console.ReadLine();
            if (f == "1")
            {
                Console.WriteLine("Wprowadź ilość cali:");
                double a = double.Parse(Console.ReadLine());
                a *= d;
                Console.WriteLine("Wynik = " + a + " cm");
            }
            else if (f == "2")
            {
                Console.WriteLine("Wprowadź ilość cm:");
                double a = double.Parse(Console.ReadLine());
                a /= d;
                Console.WriteLine("Wynik = " + a + " cal(i)");
            }
            Console.ReadLine();
        }
    }
}


