﻿using System;

namespace Program1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Witaj na laboratorium nr 1 !!!");
            Console.ReadKey();
            Console.Write("Zaczynamy zabawe z C# ");
            Console.ReadKey();
        }
    }
}


