﻿using System;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Każdy wiek ma goryczy, ma swoje przywary;");
            Console.WriteLine("Syn się męczył nad książką, stękał ojciec stary.");
            Console.WriteLine("Ten nie miał odpoczynku, a tamten swobody: ");
            Console.WriteLine("Płakał ojciec, że stary; płakał syn, że młody.");
            Console.WriteLine();
            Console.WriteLine("Ignacy Krasicki");
            Console.ReadLine();
        }
    }
}


