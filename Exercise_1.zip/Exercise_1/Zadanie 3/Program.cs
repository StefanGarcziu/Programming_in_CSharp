﻿using System;

namespace Zadanie_3
{
    class Program
    {
        static void Main(string[] args)
        {
            double b;
            double h;
            int a = 2;
            int c = 3;

            Console.Write("Podaj bok podstawy: ");
            b = Convert.ToDouble(Console.ReadLine());
            Console.Write("Podaj wysokość h: ");
            h = Convert.ToDouble(Console.ReadLine());

            // Pole powierzchni
            double lateral_surface_area = a * b * Math.Sqrt(Math.Pow(h, a) + Math.Pow(b/a, a));
            double base_area = Math.Pow(b, a);
            double surface_area = lateral_surface_area + base_area ;

            // Objętość
            double volume = (Math.Pow(b, a) * h) / c;

            Console.WriteLine("Pole = {0}\nObjętość = {1}", surface_area, volume);            
        }
    }
}

