﻿using System;

namespace Zadanie_5
{
    class Program
    {
        static void Main(string[] args)
        {           
            double p;
            double t;
            double m;            
            int a = 100;
            int b = 12;
            int c = 1;
                     
            Console.Write("Oprocentowanie (za 12 miesięcy): ");
            p = Convert.ToDouble(Console.ReadLine());
            Console.Write("Okres oszczędzania (wskazać liczbę miesięcy): ");
            t = Convert.ToDouble(Console.ReadLine());
            Console.Write("Zdeponowana kwota (w euro): ");
            m = Convert.ToDouble(Console.ReadLine());            

            double s = ((t/b * p) / a + c) * m;
                    
            Console.WriteLine("Obliczanie opłacalności depozytu = {0:f2} ", s);                  
            Console.ReadLine();
            
        }
    }
}
