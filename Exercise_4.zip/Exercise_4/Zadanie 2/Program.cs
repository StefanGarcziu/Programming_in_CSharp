﻿using System;
namespace Zadanie_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Program obj = new Program();

            int variable_1 = 10;
            Console.WriteLine("Wewnątrz Main() – Przed przed metodą TestRef(): a = {0}", variable_1);
            obj.TestRef();
            Console.WriteLine("Wewnątrz Main() – Po metodzie TestRef(): a = {0}", variable_1);
            Console.WriteLine();
            Console.WriteLine();

            int variable_2 = 10;
            Console.WriteLine("Wewnątrz Main() – Przed przed metodą TestOut(): a = {0}", variable_2);
            obj.TestOut();
            Console.WriteLine("Wewnątrz Main() – Po metodzie TestOut(): a = {0}", variable_2);
            Console.WriteLine();
            Console.WriteLine();

            int variable_3 = 10;
            Console.WriteLine("Wewnątrz Main() – Przed metodą ByRef(): a = {0}", variable_3);            
            obj.ByRef(ref variable_3);            
            Console.WriteLine("Wewnątrz Main() – Po metodzie ByRef(): a = {0}", variable_3);            
            Console.WriteLine();
            Console.WriteLine();


            int variable_4 = 10;
            Console.WriteLine("Wewnątrz Main() – Przed przed metodą ByOut(): a = {0}", variable_4);           
            obj.ByOut(out variable_2);            
            Console.WriteLine("Wewnątrz Main() – Po metodzie ByOut(): a = {0}", variable_4);            
            Console.WriteLine();
            Console.WriteLine();        


            Console.ReadKey();
        }
        
        public void ByRef(ref int value)
        {
            Console.WriteLine(nameof(ByRef) + value);
            value += 4;
            Console.WriteLine(nameof(ByRef) + value);
        }
        public void TestRef()
        {
            //int refValue1;
            //ByRef(ref refValue1); 

            int refValue2 = 0;
            ByRef(ref refValue2);
            int refValue3 = 10;
            ByRef(ref refValue3);
        }
        public void ByOut(out int value)
        {
            //value += 4;
            //Console.WriteLine(nameof(ByOut) + value);

            value = 4;
            Console.WriteLine(nameof(ByOut) + value);
        }
        public void TestOut()
        {
            int outValue1;
            ByOut(out outValue1);
            int outValue2 = 10;
            ByOut(out outValue2);
        }
    }
}
