﻿using System;
namespace Zadanie_1
{
    class Program
    {
        static void DivisibleByFour(int n)
        {
            int remainder;
            int i = 1;
            while (i <= n)
            {
                remainder = i % 4;
                {
                    if (remainder == 0)
                        Console.WriteLine(" {0}", i);
                }
                i++;
            }
            Console.WriteLine();
        }
        static void Main(string[] args)
        {
            int n = 30;
            Console.WriteLine(" Liczby całkowite od l do 30 podzielne przez 4: ");
            DivisibleByFour(n);         
        }
    }
}
