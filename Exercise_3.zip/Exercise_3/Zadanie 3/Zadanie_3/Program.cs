﻿using System;

namespace Zadanie_3
{
    class Program
    {
        static void Conversion(double f, double a)
        {
            if (f == 1)
            {
                a *= 2.54;
                Console.WriteLine("Wynik = " + a + " cm");
            }
            else if (f == 2)
            {
                a /= 2.54;
                Console.WriteLine("Wynik = " + a + " cal(e)");
            }
        }
        static void Main(string[] args)
        { 
            Console.Write("Wpisz 1 lub 2 (1 - cale na cm, 2 - cm na cale): ");
            double f = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Wprowadź ilość cali:");
            double a = double.Parse(Console.ReadLine());

            Conversion(f, a);

            Console.ReadLine();
        }
    }
}
