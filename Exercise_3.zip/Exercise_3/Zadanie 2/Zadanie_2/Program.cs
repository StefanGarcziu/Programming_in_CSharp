﻿using System;
namespace Zadanie_2
{
    class Program
    {
        static void Divisible(int n)
        {
            for (int i = n; i > 0; i--)
            {
                int remainder_1 = n % 3;
                int remainder_2 = n % 2;
                if (remainder_1 == 0 && remainder_2 != 0)
                {                    
                    Console.WriteLine(n);                    
                }
                n--;
            }
            Console.WriteLine();
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Podaj n: ");
            int n = int.Parse(Console.ReadLine());
            Console.WriteLine("Liczby podzielne przez 3, ale niepodzielne przez 2: ");
            Divisible(n);
        }
    }
}
