﻿using System;
namespace Zadanie1
{
    class Program
    {
        static double[,] ReadMatrix(int r, int c)
        {
            double[,] mat = new double[r, c];

            for (int i = 0; i < r; i++)
                for (int j = 0; j < c; j++)
                    mat[i, j] = double.Parse(Console.ReadLine());       
            return mat;            
        }

        static double CountDown(double[,] mat)
        {
            int n = mat.GetLength(0);
            double sum = 0;

            for (int i = 0; i < n; i++)
                for (int j = 0; j <= i; j++)
                    sum += mat[i, j];
            return sum;
        }

        static void Main(string[] args)
        {
            Console.Write("Podaj ilość wierszy: ");
            int w = int.Parse(Console.ReadLine());
            Console.Write("Podaj ilość kolumn: ");
            int k = int.Parse(Console.ReadLine());
            Console.Write("Wprowadź pierwszy element, a następnie następujące: ");

            double[,] mat2 =  ReadMatrix(w, k);
            double a = CountDown(mat2);
            Console.Write("Suma w lewym dolnym rogu = {0} ", a);

            Console.ReadLine();
        }
    }
}
