﻿using System;
namespace Zadanie2
{
    class Program
    {
        static double[,] ReadMatrix(int r, int c)
        {
            double[,] mat = new double[r, c];
            for (int i = 0; i < r; i++)
                for (int j = 0; j < c; j++)
                    mat[i, j] = double.Parse(Console.ReadLine());
            return mat;
        }

        static double[,] Multiplication(double[,] a, double[,] b)
        {
            double[,] result = new double[a.GetLength(0), b.GetLength(1)];
            if (a.Rank != 3 && b.Rank != 3)
            {
                for (int i = 0; i < a.GetLength(0); i++)
                {
                    for (int j = 0; j < b.GetLength(1); j++)
                    {
                        for (int k = 0; k < b.GetLength(0); k++)
                        {
                            result[i, j] += a[i, k] * b[k, j];
                        }
                    }
                }
            }
            else
            {
                Console.WriteLine("Sprawdź i ponownie podaj wymiary obu macierzy !");
            }
            return result;
        }

        static void Result(double[,] r)
        {
            for (int j = 0; j < r.GetLength(0); j++)
            {
                for (int i = 0; i < r.GetLength(1); i++)
                    Console.Write("{0} ", r[j, i]);
                Console.WriteLine();
            }
        }

        static void Main(string[] args)
        {
            Console.Write("Podaj ilość wierszy macierzy A: ");
            int w1 = int.Parse(Console.ReadLine());
            Console.Write("Podaj ilość kolumn macierzy A: ");
            int k1 = int.Parse(Console.ReadLine());
            Console.Write("Wprowadź pierwszy element, a następnie następujące: ");
            double[,] mat1 = ReadMatrix(w1, k1);

            Console.Write("Podaj ilość wierszy macierzy B: ");
            int w2 = int.Parse(Console.ReadLine());
            Console.Write("Podaj ilość kolumn macierzy B: ");
            int k2 = int.Parse(Console.ReadLine());
            Console.Write("Wprowadź pierwszy element, a następnie następujące: ");
            double[,] mat2 = ReadMatrix(w2, k2);

            Console.WriteLine("\nMacierz A: ");
            for (int j = 0; j < mat1.GetLength(0); j++)
            {                
                for (int i = 0; i < mat1.GetLength(1); i++)                
                Console.Write("{0} ", mat1[j, i]);
                Console.WriteLine();
            }
            Console.WriteLine("\nMacierz B: ");
            for (int j = 0; j < mat2.GetLength(0); j++)
            {                
                for (int i = 0; i < mat2.GetLength(1); i++)                    
                Console.Write("{0} ", mat2[j, i]);
                Console.WriteLine();
            }            
            if (mat1.GetLength(1) == mat2.GetLength(0))
            {
                double[,] mat3 = Multiplication(mat1, mat2);
                Console.WriteLine("\nC = A * B ");
                Result(mat3);
            }
            else
            {
                Console.WriteLine("Macierzy o podanych wymiarach nie można mnożyć!");
            }
            Console.ReadLine();
        }
    }
}


