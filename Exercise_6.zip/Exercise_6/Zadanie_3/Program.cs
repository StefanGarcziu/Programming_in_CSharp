﻿using System;
namespace Zadanie3
{
    class Program
    {
        static double[,] ReadMatrix(int r, int c)
        {
            double[,] mat = new double[r, c];
            for (int i = 0; i < r; i++)
                for (int j = 0; j < c; j++)
                    mat[i, j] = double.Parse(Console.ReadLine());
            return mat;
        }

        static double UpperDiagonal(double[,] mat1)
        {
            double sum1 = 0;
            if (mat1.GetLength(0) < mat1.GetLength(1))
            {
                for (int i = 0; i < mat1.GetLength(0); i++)
                {
                    int j = i + 1;
                    sum1 += mat1[i, j];
                }
            }
            else if (mat1.GetLength(0) > mat1.GetLength(1))
            {
                int i = 0;
                for (int j = 1; j < mat1.GetLength(1); j++)
                {
                    sum1 += mat1[i, j];
                    i = j;
                }
            }
            else           
            {
                for (int i = 0; i < mat1.GetLength(0) - 1; i++)
                {
                    int j = i + 1;
                    sum1 += mat1[i, j];
                }
            }     
            return sum1;
        }

        static double LowerDiagonal(double[,] mat2)
        {
            double sum2 = 0;
            if (mat2.GetLength(0) > mat2.GetLength(1))
            {
                for (int j = 0; j < mat2.GetLength(1); j++)
                {
                    int i = j + 1;
                    sum2 += mat2[i, j];
                }
            }
            else if (mat2.GetLength(0) < mat2.GetLength(1))
            {
                int j = 0;
                for (int i = 1; i < mat2.GetLength(0); i++)
                {                    
                    sum2 += mat2[i, j];
                    j = i;
                }
            }
            else
            {
                for (int j = 0; j < mat2.GetLength(1) - 1; j++)
                {
                    int i = j + 1;
                    sum2 += mat2[i, j];
                }
            }
            return sum2;
        }

        static void Main(string[] args)
        {
            Console.Write("Podaj ilość wierszy: ");
            int w = int.Parse(Console.ReadLine());
            Console.Write("Podaj ilość kolumn: ");
            int k = int.Parse(Console.ReadLine());
            Console.Write("Wprowadź pierwszy element, a następnie następujące: ");            

            double[,] mat = ReadMatrix(w, k);
            double up = UpperDiagonal(mat);
            double down = LowerDiagonal(mat);
            Console.Write("Suma górnej przekątnej  = {0} ", up);
            Console.WriteLine();
            Console.Write("Suma dolnej przekątnej  = {0} ", down);

            Console.ReadLine();
        }
    }
}


