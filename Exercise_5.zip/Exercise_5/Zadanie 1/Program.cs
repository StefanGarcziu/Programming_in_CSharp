﻿using System;

namespace Zadanie_1
{
    class Program
    {
        static void Main(string[] args)
        {
            bool[] a = new bool[15];

            int total = 0;
            foreach (bool x in a)
            {
                if (total % 2 != 0)
                    a[total] = true;
                Console.WriteLine("Index={0}, {1}",total, a[total]);
                total++;
            }   
        }
    }
}
