﻿using System;

namespace Zadanie_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] tablica = new int[100];

            int i = 0;
            foreach (int tabl in tablica)
            {
                Console.WriteLine("tablica [{0}] {1}", i, tablica[tabl]);
                tablica[tabl]++;
                i++;
            }
            Console.ReadLine();
        }
    }
}

