﻿using System;

namespace Zadanie_3
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] a = new int[100];
            int i = 0;
            int j = 0;
            while (i < a.Length)
            {
                a[i] = j;
                Console.WriteLine("Element tabeli: a[{0}] Wartość: {1}", i, a[i]);
                j++;
                if(j == 10)
                {
                    j = 0;
                    Console.WriteLine();
                }
                i++;
            }
        }
    }
}





